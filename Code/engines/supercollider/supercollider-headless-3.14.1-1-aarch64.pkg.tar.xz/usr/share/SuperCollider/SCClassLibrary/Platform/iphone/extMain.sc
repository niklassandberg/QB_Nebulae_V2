+ Main {
	platformClass { ^IPhonePlatform }
}
