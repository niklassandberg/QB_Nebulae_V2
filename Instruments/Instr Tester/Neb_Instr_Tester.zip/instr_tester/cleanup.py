import RPi.GPIO as GPIO

GPIO.cleanup()
